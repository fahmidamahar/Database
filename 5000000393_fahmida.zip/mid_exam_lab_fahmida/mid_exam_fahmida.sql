CREATE DATABASE HR;
USE HR;
CREATE TABLE departments (
    department_id INT PRIMARY KEY,
    department_name VARCHAR(50)
);
CREATE TABLE employees (
    employee_id INT PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    manager_id INT,
    department_id INT,
    salary DECIMAL(10,2),
    FOREIGN KEY (department_id) REFERENCES departments(department_id)
);
INSERT INTO departments VALUES
(10, 'HR'),
(20, 'IT'),
(30, 'Finance'),
(40, 'Marketing');
INSERT INTO employees VALUES
(1, 'John', 'Smith', NULL, 20, 7000),
(2, 'Sarah', 'Johnson', 1, 20, 6000),
(3, 'Michael', 'Brown', 1, 30, 5500),
(4, 'Emily', 'Davis', 2, 10, 4500),
(5, 'David', 'Wilson', 3, 40, 5200);
SELECT
    e.first_name,
    e.last_name,
    e.manager_id,
    d.department_name
FROM employees AS e
JOIN departments AS d
ON e.department_id = d.department_id
WHERE d.department_name = 'IT';
SELECT
    first_name,
    last_name,
    department_id,
    salary
FROM employees
WHERE salary > 5000
AND department_id NOT IN (10, 40);
