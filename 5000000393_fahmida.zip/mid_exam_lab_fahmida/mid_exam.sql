show databases;
use HR;
Describe employees;
-- Question1(a)
select e.first_name,last_name, department_name
from employees e
RIGHT JOIN departments d
ON e.department_id = d.department_id;

SELECT employee_id, e.job_id, d.department_name
FROM employees e
INNER JOIN departments d
ON e.department_id = d.department_id;
-- QUESTION 1(B)
select e.first_name,last_name,department_name
from employees e
Inner join departments d
ON e.department_id = d.department_id;   

-- Qucestion1(c)
SELECT *
FROM employees
RIGHT JOIN departments
ON employees.department_id = departments.department_id;
-- question1(d)
